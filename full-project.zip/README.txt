這個連結可以點嗎？給大學生的釣魚訊息辨識入門

開啟方式
1. 解壓縮整份成果。
2. 用 Chrome 或 Edge 開啟 dist/index.html，即可離線換頁與作答。
3. 上方可切換到 Wiki 與流程紀錄。請保留 dist 內的資料夾結構，讓頁面間連結能正常運作。

檔案內容
- dist/index.html：11 頁 HTML 教學闖關，包含三道決策題、即時解析與評分。
- dist/wiki.html：可搜尋的靜態 LLM Wiki。
- dist/workflow.html：流程、來源對照、實際執行紀錄與反思。
- dist/knowledge.json：六篇資料摘要、五個 Wiki 頁面、十五個來源可追溯重點。
- dist/sources/：六篇官方來源的摘要筆記、URL 與適用範圍。
- dist/wiki/：Wiki Markdown 成果。
- dist/records/：實際檢索結果、三輪檢查歷史、投影片對照、結構與邏輯測試、瀏覽器觀察。
- scripts/：可重現檢索、覆蓋檢查、HTML 建置與程式驗證的 Node 腳本。

重現方式（已安裝 Node 的電腦）
在本資料夾依序執行：
node scripts/retrieve.mjs
node scripts/check-grounding.mjs
node scripts/build.mjs
node scripts/validate.mjs
重新執行會更新時間戳與附加新的檢查結果；原本三輪紀錄已保留在 dist/records/grounding-history.json。

使用與驗證範圍
本成果由 Codex 協助整理來源、建立 Wiki、撰寫 HTML 與檢查腳本；使用者選定主題與情境闖關玩法。
這是 LLM 協作生成的靜態 Wiki，非特定平台，不含向量資料庫或瀏覽時的 LLM API。
已通過程式驗證與 Chrome 首頁目視檢查；逐關瀏覽器點擊與手機實機驗證尚未完成，繳交前請自行試玩。
來源筆記是摘要，並未複製完整原文。所有關卡都是自製示例，並非實際校方通知。
若老師課堂指定特定 LLM Wiki 工具，請把附上的來源與 Markdown 匯入該工具，再補上平台連結。
