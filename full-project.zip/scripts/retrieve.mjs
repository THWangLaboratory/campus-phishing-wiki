import fs from 'node:fs';
const base=new URL('../dist/',import.meta.url);
const kb=JSON.parse(fs.readFileSync(new URL('knowledge.json',base),'utf8'));
const queries=[['Q01','帳號停用要怎麼查證',['帳號','停用','查證']],['Q02','包裹補費怎麼確認',['包裹','付款','物流']],['Q03','HTTPS 和校名能證明獎學金網站可信嗎（加入案例查詢意圖）',['HTTPS','網址','獎學金','案例']],['Q04','誤點並輸入密碼之後如何處理',['誤點','密碼','處理']]];
const result=queries.map(([id,query,tokens])=>({id,query,method:`以人工指定中文關鍵字對 Wiki tags 做詞彙檢索，取前 ${id==='Q03'?4:3} 頁；非向量資料庫`,hits:kb.pages.map(p=>({page:p.id,score:tokens.filter(t=>p.tags.includes(t)).length,claims:p.claims})).filter(p=>p.score>0).sort((a,b)=>b.score-a.score||a.page.localeCompare(b.page)).slice(0,id==='Q03'?4:3)}));
fs.writeFileSync(new URL('records/retrieval.json',base),JSON.stringify({executedAt:new Date().toISOString(),queries:result},null,2));
console.log(JSON.stringify(result.map(q=>({id:q.id,hits:q.hits.map(p=>({page:p.page,score:p.score}))})),null,2));

