import fs from 'node:fs';
const base=new URL('../dist/',import.meta.url);
const retrieval=JSON.parse(fs.readFileSync(new URL('records/retrieval.json',base),'utf8'));
const requirements={Q01:['C01','C07','C13'],Q02:['C08','C14'],Q03:['C04','C07','C15'],Q04:['C09','C10','C11']};
const checks=retrieval.queries.map(q=>{const found=new Set(q.hits.flatMap(p=>p.claims.map(c=>c.id)));return {query:q.id,required:requirements[q.id],missing:requirements[q.id].filter(c=>!found.has(c))};});
const ok=checks.every(c=>c.missing.length===0);
const path=new URL('records/grounding-history.json',base);
const history=fs.existsSync(path)?JSON.parse(fs.readFileSync(path,'utf8')):[];
history.push({executedAt:new Date().toISOString(),result:ok?'PASS':'FAIL',checks});
fs.writeFileSync(path,JSON.stringify(history,null,2));
console.log(JSON.stringify(history.at(-1),null,2));
process.exitCode=ok?0:1;

